# GlucoLens — Diabetes Prediction & Model Comparison

A Flask + scikit-learn capstone dashboard comparing Decision Tree, k-NN, Gaussian Naïve Bayes and Multi-Layer Perceptron on the Pima Indians Diabetes Database.

## Dataset
- OpenML dataset 37: https://www.openml.org/d/37
- Static ARFF download: https://data.openml.org/datasets/0000/0037/dataset_37.arff
- 768 rows, 8 clinical input features, binary target.
- Historical population limitation: the records concern women aged 21+ from the Pima population near Phoenix, Arizona. Results must not be generalized to all populations.

The dataset is downloaded automatically the first time the application runs. The downloaded CSV is stored in `data/`.

## Run on Windows
1. Install Python 3.10 or newer.
2. Extract this ZIP.
3. Double-click `run_windows.bat`.
4. Wait for package installation and model training to finish.
5. Open http://127.0.0.1:5000 in your browser.

## Run on macOS / Linux
```bash
chmod +x run_mac_linux.sh
./run_mac_linux.sh
```
Then open http://127.0.0.1:5000.

## What happens during training
- One stratified 80/20 train/test split with random_state=42.
- Zero placeholders in Glucose, Blood Pressure, Skin Thickness, Insulin and BMI are treated as missing.
- Median imputation and standard scaling are fitted inside each model pipeline on training data only.
- All four classifiers use the same split.
- Accuracy, precision, recall, F1, ROC-AUC, confusion matrices and ROC curve coordinates are generated from the held-out test set.
- A majority-vote result is also calculated from the four classifiers.
- Model pipelines and evaluation JSON are saved under `models/`.

## Important project notes
- The prediction screen is a research demonstration, not a medical device.
- A single 80/20 split is useful for a capstone prototype but is not a robust estimate of generalization. Consider repeated stratified cross-validation for the final report.
- Do not describe the hard-voting result as a trained fifth model; it is a simple voting combination of the four classifiers.
- Metrics are generated locally on the first run. Do not quote results until training completes and you inspect the dashboard.
- Keep the `models/` and `data/` folders with the project if you want to preserve the trained artifacts and downloaded data.

## Project citation
Smith, J. W., Everhart, J. E., Dickson, W. C., Knowler, W. C., & Johannes, R. S. (1988). Using the ADAP learning algorithm to forecast the onset of diabetes mellitus. *Proceedings of the Symposium on Computer Applications and Medical Care*, 261–265. Dataset record: OpenML dataset 37 (Pima Indians Diabetes Database), originally obtained from UCI.
