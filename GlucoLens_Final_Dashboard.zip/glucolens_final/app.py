from flask import Flask, render_template, request, jsonify
from pathlib import Path
import json
import numpy as np
import joblib
from train import train_and_save, FEATURES, MODEL_NAMES

BASE = Path(__file__).resolve().parent
MODEL_DIR = BASE / "models"
RESULTS_FILE = MODEL_DIR / "evaluation.json"
app = Flask(__name__)
history = []

def ensure_models():
    expected = [MODEL_DIR / f"{key}.joblib" for key in MODEL_NAMES]
    if not RESULTS_FILE.exists() or not all(p.exists() for p in expected):
        train_and_save()

def get_results():
    ensure_models()
    return json.loads(RESULTS_FILE.read_text(encoding="utf-8"))

@app.get("/")
def home():
    return render_template("index.html")

@app.get("/api/metrics")
def metrics():
    return jsonify(get_results())

@app.post("/api/predict")
def predict():
    ensure_models()
    payload = request.get_json(silent=True) or {}
    try:
        row = [float(payload[name]) for name in FEATURES]
        if not np.all(np.isfinite(row)):
            raise ValueError("All values must be finite numbers.")
        if any(v < 0 for v in row):
            raise ValueError("Values cannot be negative.")
        limits = {
            "Pregnancies": 20, "Glucose": 300, "BloodPressure": 200,
            "SkinThickness": 100, "Insulin": 900, "BMI": 90,
            "DiabetesPedigreeFunction": 3, "Age": 120
        }
        for name, value in zip(FEATURES, row):
            if value > limits[name]:
                raise ValueError(f"{name} is outside the accepted demo range.")
    except (KeyError, TypeError, ValueError) as exc:
        return jsonify({"error": str(exc)}), 400

    X = np.array(row, dtype=float).reshape(1, -1)
    model_results = {}
    votes = []
    probs = []
    for key, label in MODEL_NAMES.items():
        model = joblib.load(MODEL_DIR / f"{key}.joblib")
        pred = int(model.predict(X)[0])
        probability = float(model.predict_proba(X)[0][1])
        votes.append(pred)
        probs.append(probability)
        model_results[key] = {
            "label": label,
            "prediction": pred,
            "class_label": "Positive" if pred else "Negative",
            "probability": round(probability * 100, 1)
        }

    positive_votes = int(sum(votes))
    ensemble_prediction = int(positive_votes >= 2)
    ensemble_probability = float(np.mean(probs))
    item = {
        "id": len(history) + 1,
        "ensemble_prediction": ensemble_prediction,
        "ensemble_label": "Positive" if ensemble_prediction else "Negative",
        "ensemble_probability": round(ensemble_probability * 100, 1),
        "positive_votes": positive_votes,
        "total_models": len(votes),
        "models": model_results,
        "inputs": dict(zip(FEATURES, row))
    }
    history.insert(0, item)
    del history[20:]
    return jsonify(item)

@app.get("/api/history")
def get_history():
    return jsonify(history)

if __name__ == "__main__":
    ensure_models()
    app.run(host="127.0.0.1", port=5000, debug=True)
