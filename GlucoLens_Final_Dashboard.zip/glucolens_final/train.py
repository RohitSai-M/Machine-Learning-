from pathlib import Path
from io import BytesIO
import json
import urllib.request
import warnings
import numpy as np
import pandas as pd
import joblib
from scipy.io import arff
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve
)

BASE = Path(__file__).resolve().parent
DATA_DIR = BASE / "data"
MODEL_DIR = BASE / "models"
DATA_FILE = DATA_DIR / "pima_diabetes.csv"
ARFF_URL = "https://data.openml.org/datasets/0000/0037/dataset_37.arff"

FEATURES = [
    "Pregnancies", "Glucose", "BloodPressure", "SkinThickness",
    "Insulin", "BMI", "DiabetesPedigreeFunction", "Age"
]
MODEL_NAMES = {
    "decision_tree": "Decision Tree",
    "knn": "k-Nearest Neighbors",
    "naive_bayes": "Gaussian Naïve Bayes",
    "mlp": "Multi-Layer Perceptron"
}
SEED = 42

def load_dataset():
    DATA_DIR.mkdir(exist_ok=True)
    if DATA_FILE.exists():
        return pd.read_csv(DATA_FILE)
    print("Downloading Pima Indians Diabetes data from OpenML...")
    request = urllib.request.Request(ARFF_URL, headers={"User-Agent": "GlucoLens-Capstone/1.0"})
    with urllib.request.urlopen(request, timeout=45) as response:
        raw = response.read()
    records, metadata = arff.loadarff(BytesIO(raw))
    df = pd.DataFrame(records)
    df.columns = [str(c).strip().lower() for c in df.columns]
    # OpenML dataset 37 stores the binary target as tested_negative/tested_positive.
    target_col = "class" if "class" in df.columns else df.columns[-1]
    y = df[target_col].astype(str).str.replace("b'", "", regex=False).str.replace("'", "", regex=False).str.strip()
    df[target_col] = y.map({
        "tested_negative": 0, "tested_positive": 1,
        "0": 0, "1": 1, "negative": 0, "positive": 1
    })
    aliases = {
        "preg": "Pregnancies", "pregnancies": "Pregnancies",
        "plas": "Glucose", "glucose": "Glucose",
        "pres": "BloodPressure", "bloodpressure": "BloodPressure",
        "skin": "SkinThickness", "skinthickness": "SkinThickness",
        "insu": "Insulin", "insulin": "Insulin",
        "mass": "BMI", "bmi": "BMI",
        "pedi": "DiabetesPedigreeFunction", "diabetespedigreefunction": "DiabetesPedigreeFunction",
        "age": "Age"
    }
    rename = {}
    for col in df.columns:
        clean = col.replace("_", "").replace("-", "").lower()
        if clean in aliases:
            rename[col] = aliases[clean]
    df = df.rename(columns=rename)
    missing = [f for f in FEATURES if f not in df.columns]
    if missing:
        raise RuntimeError(f"Dataset schema did not contain expected features: {missing}. Found: {list(df.columns)}")
    df = df[FEATURES + [target_col]].rename(columns={target_col: "Outcome"})
    df = df.dropna(subset=["Outcome"])
    df["Outcome"] = df["Outcome"].astype(int)
    df.to_csv(DATA_FILE, index=False)
    return df

def build_models():
    # Scaling is included in every pipeline for a consistent preprocessing workflow.
    return {
        "decision_tree": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("classifier", DecisionTreeClassifier(max_depth=4, min_samples_leaf=8, class_weight="balanced", random_state=SEED))
        ]),
        "knn": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("classifier", KNeighborsClassifier(n_neighbors=11, weights="distance"))
        ]),
        "naive_bayes": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("classifier", GaussianNB())
        ]),
        "mlp": Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            ("classifier", MLPClassifier(hidden_layer_sizes=(32, 16), activation="relu",
                                         solver="adam", alpha=0.001, learning_rate_init=0.001,
                                         max_iter=1500, early_stopping=True, validation_fraction=0.15,
                                         n_iter_no_change=30, random_state=SEED))
        ])
    }

def train_and_save():
    warnings.filterwarnings("ignore", category=UserWarning)
    MODEL_DIR.mkdir(exist_ok=True)
    df = load_dataset()
    X = df[FEATURES].astype(float).copy()
    y = df["Outcome"].astype(int).copy()

    # In this dataset, zero is an invalid placeholder for these measurements.
    # It is treated as missing and imputed using training-fold medians.
    zero_missing = ["Glucose", "BloodPressure", "SkinThickness", "Insulin", "BMI"]
    X.loc[:, zero_missing] = X[zero_missing].replace(0, np.nan)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, stratify=y, random_state=SEED
    )
    trained = {}
    evaluations = {}
    for key, model in build_models().items():
        print(f"Training {MODEL_NAMES[key]}...")
        model.fit(X_train, y_train)
        pred = model.predict(X_test)
        prob = model.predict_proba(X_test)[:, 1]
        cm = confusion_matrix(y_test, pred, labels=[0, 1])
        fpr, tpr, thresholds = roc_curve(y_test, prob)
        metrics = {
            "accuracy": round(float(accuracy_score(y_test, pred)) * 100, 2),
            "precision": round(float(precision_score(y_test, pred, zero_division=0)) * 100, 2),
            "recall": round(float(recall_score(y_test, pred, zero_division=0)) * 100, 2),
            "f1": round(float(f1_score(y_test, pred, zero_division=0)) * 100, 2),
            "roc_auc": round(float(roc_auc_score(y_test, prob)) * 100, 2)
        }
        evaluations[key] = {
            "name": MODEL_NAMES[key],
            "metrics": metrics,
            "confusion_matrix": cm.tolist(),
            "roc": {
                "fpr": [round(float(v), 5) for v in fpr],
                "tpr": [round(float(v), 5) for v in tpr]
            }
        }
        joblib.dump(model, MODEL_DIR / f"{key}.joblib")
        trained[key] = model

    # Simple hard-voting ensemble; individual models remain separately visible.
    test_predictions = np.column_stack([m.predict(X_test) for m in trained.values()])
    ensemble_pred = (test_predictions.sum(axis=1) >= 2).astype(int)
    evaluations["majority_vote"] = {
        "name": "Majority Vote",
        "metrics": {
            "accuracy": round(float(accuracy_score(y_test, ensemble_pred)) * 100, 2),
            "precision": round(float(precision_score(y_test, ensemble_pred, zero_division=0)) * 100, 2),
            "recall": round(float(recall_score(y_test, ensemble_pred, zero_division=0)) * 100, 2),
            "f1": round(float(f1_score(y_test, ensemble_pred, zero_division=0)) * 100, 2),
            "roc_auc": None
        },
        "confusion_matrix": confusion_matrix(y_test, ensemble_pred, labels=[0, 1]).tolist(),
        "roc": None
    }

    result = {
        "dataset": {
            "name": "Pima Indians Diabetes Database",
            "source": "OpenML dataset 37",
            "instances": int(len(df)),
            "features": len(FEATURES),
            "positive": int((y == 1).sum()),
            "negative": int((y == 0).sum()),
            "train_size": int(len(X_train)),
            "test_size": int(len(X_test)),
            "split": "80% training / 20% testing",
            "random_state": SEED,
            "preprocessing": "Zero placeholders in Glucose, Blood Pressure, Skin Thickness, Insulin and BMI treated as missing; median imputation fitted on training data; standard scaling."
        },
        "features": FEATURES,
        "models": evaluations,
        "best_model": max(
            [k for k in evaluations if k != "majority_vote"],
            key=lambda k: evaluations[k]["metrics"]["f1"]
        )
    }
    (MODEL_DIR / "evaluation.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(f"Saved model artifacts and evaluation to {MODEL_DIR}")
    return result

if __name__ == "__main__":
    train_and_save()
