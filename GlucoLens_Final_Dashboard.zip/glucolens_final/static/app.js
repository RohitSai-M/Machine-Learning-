let dashboardData=null, metricsChart=null, rocChart=null;
const $=id=>document.getElementById(id);
function toast(message){const t=$('toast');t.textContent=message;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2800)}
async function loadDashboard(){
 try{
  const res=await fetch('/api/metrics');if(!res.ok)throw new Error('Could not load model evaluation.');
  dashboardData=await res.json();renderDashboard();loadHistory();
 }catch(e){toast(e.message)}
}
function pct(v){return v==null?'—':Number(v).toFixed(2)+'%'}
function renderDashboard(){
 const d=dashboardData.dataset,m=dashboardData.models;
 $('records').textContent=d.instances.toLocaleString();$('features').textContent=d.features;
 $('split').textContent=d.train_size+' / '+d.test_size;
 $('positive-count').textContent=d.positive;$('negative-count').textContent=d.negative;
 $('positive-pct').textContent=(100*d.positive/d.instances).toFixed(1)+'%';
 const pos=100*d.positive/d.instances;$('class-donut').style.background=`conic-gradient(#627af1 0 ${pos}%,#e9edf6 ${pos}% 100%)`;
 const keys=['decision_tree','knn','naive_bayes','mlp','majority_vote'];
 const body=$('metrics-body');body.innerHTML=keys.map(k=>{
  const x=m[k],v=x.metrics;return `<tr><td>${x.name}</td><td><span class="score-pill">${pct(v.accuracy)}</span></td><td>${pct(v.precision)}</td><td>${pct(v.recall)}</td><td>${pct(v.f1)}</td><td>${pct(v.roc_auc)}</td></tr>`;
 }).join('');
 const best=m[dashboardData.best_model];$('best-model').innerHTML=`Top individual model by F1-score: <b>${best.name}</b> · ${pct(best.metrics.f1)} F1-score.`;
 const ctx=$('metrics-chart');
 if(metricsChart)metricsChart.destroy();
 metricsChart=new Chart(ctx,{type:'bar',data:{labels:keys.map(k=>m[k].name),datasets:[
  {label:'Accuracy',data:keys.map(k=>m[k].metrics.accuracy),backgroundColor:'#6078ef',borderRadius:5},
  {label:'Precision',data:keys.map(k=>m[k].metrics.precision),backgroundColor:'#36b49e',borderRadius:5},
  {label:'Recall',data:keys.map(k=>m[k].metrics.recall),backgroundColor:'#e6aa61',borderRadius:5},
  {label:'F1-score',data:keys.map(k=>m[k].metrics.f1),backgroundColor:'#9a83e8',borderRadius:5}
 ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:8,font:{size:9}}}},scales:{y:{min:0,max:100,grid:{color:'#edf0f5'},ticks:{font:{size:9}}},x:{grid:{display:false},ticks:{font:{size:9}}}}}});
 const rocKeys=['decision_tree','knn','naive_bayes','mlp'];
 const colors=['#6078ef','#36b49e','#e6aa61','#9a83e8'];
 if(rocChart)rocChart.destroy();
 rocChart=new Chart($('roc-chart'),{type:'line',data:{datasets:[
  ...rocKeys.map((k,i)=>({label:m[k].name+' · '+pct(m[k].metrics.roc_auc),data:m[k].roc.fpr.map((x,j)=>({x,y:m[k].roc.tpr[j]})),borderColor:colors[i],backgroundColor:colors[i],pointRadius:0,borderWidth:2,tension:.15})),
  {label:'Random baseline',data:[{x:0,y:0},{x:1,y:1}],borderColor:'#c8cfdb',borderDash:[5,5],pointRadius:0,borderWidth:1}
 ]},options:{responsive:true,maintainAspectRatio:false,plugins:{legend:{position:'bottom',labels:{boxWidth:8,font:{size:8}}}},scales:{x:{type:'linear',min:0,max:1,title:{display:true,text:'False positive rate',font:{size:9}},ticks:{font:{size:8}},grid:{color:'#edf0f5'}},y:{min:0,max:1,title:{display:true,text:'True positive rate',font:{size:9}},ticks:{font:{size:8}},grid:{color:'#edf0f5'}}}}});
 const select=$('cm-select');select.innerHTML=keys.map(k=>`<option value="${k}">${m[k].name}</option>`).join('');select.onchange=renderConfusion;renderConfusion();
}
function renderConfusion(){
 const key=$('cm-select').value,cm=dashboardData.models[key].confusion_matrix;
 const labels=[['True negative','TN'],['False positive','FP'],['False negative','FN'],['True positive','TP']];
 $('confusion-matrix').innerHTML=`<div class="cm-grid">${[cm[0][0],cm[0][1],cm[1][0],cm[1][1]].map((v,i)=>`<div class="cm-cell ${i===0?'cm-tn':i===3?'cm-tp':'cm-error'}"><b>${v}</b><small>${labels[i][0]} · ${labels[i][1]}</small></div>`).join('')}</div>`;
}
$('prediction-form').addEventListener('submit',async e=>{
 e.preventDefault();const btn=$('predict-btn');btn.disabled=true;btn.textContent='Running models…';
 const data=Object.fromEntries(new FormData(e.target).entries());
 for(const k in data)data[k]=Number(data[k]);
 try{
  const res=await fetch('/api/predict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
  const result=await res.json();if(!res.ok)throw new Error(result.error||'Prediction failed');
  renderPrediction(result);loadHistory();toast('Predictions completed by all four models.');
 }catch(err){toast(err.message)}finally{btn.disabled=false;btn.innerHTML='Run all four models <b>→</b>'}
});
function renderPrediction(r){
 $('prediction-empty').classList.add('hidden');$('prediction-result').classList.remove('hidden');
 const positive=r.ensemble_prediction===1;
 $('ensemble-label').textContent=r.ensemble_label;$('ensemble-label').className=positive?'positive':'';
 $('ensemble-percent').textContent=r.ensemble_probability+'%';
 $('vote-fill').style.width=(r.positive_votes/4*100)+'%';
 $('vote-caption').textContent=`${r.positive_votes} of 4 models voted positive · majority threshold is 2 votes.`;
 $('model-output-list').innerHTML=Object.values(r.models).map(m=>`<div class="model-output"><b>${m.label}</b><span class="${m.prediction?'positive-text':'negative-text'}">${m.class_label} · ${m.probability}%</span></div>`).join('');
}
async function loadHistory(){
 try{const res=await fetch('/api/history');const rows=await res.json();$('history-body').innerHTML=rows.length?rows.map(r=>`<tr><td>#${r.id}</td><td><span class="score-pill">${r.ensemble_label}</span></td><td>${r.positive_votes} / 4 positive</td><td>${r.ensemble_probability}%</td></tr>`).join(''):'<tr><td colspan="4">No predictions in this session yet.</td></tr>'}catch(e){}
}
loadDashboard();